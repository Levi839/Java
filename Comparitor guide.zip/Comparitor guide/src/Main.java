
import java.util.*;


//Simple Comparator guide
// This program takes a List of ints and sorts them based off of their last digit.

// The Comparator is used to define your own logic when comparing two values.
// here it is used to sort the List "nums" according to its last digit.
public class Main {
    public static void main(String[] args) {


        //Creates the Comparator, extracts the last digit of the int and compares them both to detect which one is bigger

        Comparator<Integer> com = new Comparator<Integer>() {
            public int compare(Integer i, Integer j) {
                if(i%10> j%10 )
                    return 1;
                else
                    return -1;



            }



        };
        // Creates an List of nums, adds the nums to the list (Unsorted)
        List<Integer> nums = new ArrayList<>();
        nums.add(41);
        nums.add(77);
        nums.add(54);
        nums.add(63);
        nums.add(92);


        //Uses the collections.sort method to sort the ints. By default this would only sort the ints as they are from smallest to largest.
        //However due to us defining our own login in the comparitor it takes it into account when sorting.
        Collections.sort(nums,com);


        // Prints the list as [41,92,63,54,77] the last digits are all in order :).
        System.out.println(nums);
    }

}